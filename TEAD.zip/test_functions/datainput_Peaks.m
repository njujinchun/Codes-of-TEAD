function Data = datainput_Peaks

Data.dim = 2;                      %problem dimension
Data.range.min = -4*ones(1,Data.dim);   %lower variable bounds
Data.range.max = 4*ones(1,Data.dim);    %upper variable bounds
Data.FunName = 'Peaks_Function'; %test function name
Data.Threshold = 0.08;             %desired accuracy

Data.Xvalid = gridsamp([Data.range.min;Data.range.max],51);
evalstr = ['Data.Yvalid = ',Data.FunName,'(Data.Xvalid);']; eval(evalstr);
Data.Nvalid = length(Data.Yvalid);

end