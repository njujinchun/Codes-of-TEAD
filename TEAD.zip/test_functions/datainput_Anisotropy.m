function Data = datainput_Anisotropy

Data.dim = 2;                      %problem dimension
Data.range.min = -1*ones(1,Data.dim);   %lower variable bounds
Data.range.max = 1*ones(1,Data.dim);    %upper variable bounds
Data.FunName = 'Anisotropy_Function'; %test function name
Data.Threshold = 0.01;             %desired accuracy

Data.Xvalid = gridsamp([Data.range.min;Data.range.max],51);
evalstr = ['Data.Yvalid = ',Data.FunName,'(Data.Xvalid);']; eval(evalstr);
Data.Nvalid = length(Data.Yvalid);

end